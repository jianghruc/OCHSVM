function k = hadamardfun(u,v)
global alpha
%k = tanh(p1*(u*v')+p2)
for i=1:size(u,1)
    for j=1:size(v,1)
        k(i,j)=sum(1./(1./power(abs(u(i,:)),alpha)+1./power(abs(v(j,:)),alpha)));
    end
end