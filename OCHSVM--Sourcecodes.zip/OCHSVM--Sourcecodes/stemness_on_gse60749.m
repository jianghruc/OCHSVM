function [stemness_test,SVMModel,scorehat0,scorehat] = stemness_on_gse60749()

global alpha;
alpha = 2;

I1data = importdata('traindata_self60749.csv');
t_data1 = I1data';
train_data  = [t_data1];
train_label = [ones(size(t_data1,1),1)];


I2data = importdata('testdata_self60749.csv');
t_data2 = I2data';
test_data  = t_data2;



SVMModel = fitcsvm(train_data,train_label,'KernelFunction','hadamardfun','Standardize',false);
 [yout,scorehat]=predict(SVMModel,test_data);
[yout0,scorehat0]=predict(SVMModel,train_data);
 stemness_test=min((scorehat-SVMModel.Bias)./max(scorehat0-SVMModel.Bias),1);
 stemness_train = min((scorehat0-SVMModel.Bias)./max(scorehat0-SVMModel.Bias),1);
g1 = repmat({'serum+IF'},183,1);
g2 = repmat({'2i+IF'},94,1);
g3= repmat({'NPC'},54,1);

c1 = stemness_test(1:183);
c2 = stemness_test(183+1:277);
c3=stemness_test(278:331);
boxplot([c1;c2;c3],[g1;g2;g3]);