
function [yhat] = stemness_on_embryodata()


I1data = importdata('traindata_humanembryo.csv');
t_data1 = I1data';
train_data  = [t_data1];
train_label = [ones(size(t_data1,1),1)];


I2data = importdata('testdata_humanembryo.csv');
t_data2 = I2data';
test_data  = t_data2;

global alpha;
alpha = 1;

SVMModel = fitcsvm(train_data,train_label,'KernelFunction','hadamardfun','Standardize',false);
 CVSVMModel = crossval(SVMModel);
 [~,scorePred] = kfoldPredict(CVSVMModel);
 loss=kfoldLoss(CVSVMModel)
 [yhat0,scorehat0]=predict(SVMModel,train_data);
 plot(yhat0,'go-')


 [yhat1,scorehat]=predict(SVMModel,test_data);
 yhat = scorehat(:,1)./max(scorehat0(:,1));
 yhat=min((scorehat-SVMModel.Bias)./max(scorehat0-SVMModel.Bias),1);
 figure;
 plot(yhat,'r*-')
 
yhat = [yhat(1:9); yhat(12:121);yhat(10:11)];

stem(1:3,yhat(1:3),'g*')
hold on;
stem(4:9,yhat(4:9),'b*')
hold on;
stem(10:21,yhat(10:21),'k*')
hold on;
stem(22:41,yhat(22:41),'ro')
hold on;
stem(42:57,yhat(42:57),'go')
hold on;
stem(58:87,yhat(58:87),'bo')
hold on;
stem(88:121,yhat(88:121),'ko')

g2 = repmat({'Zygote'},3,1);
g3 = repmat({'2Cell'},6,1);
g4 = repmat({'4Cell'},12,1);
g5 = repmat({'8Cell'},20,1);
g6 = repmat({'16Cell'},16,1);
g7 = repmat({'Late'},30,1);
g8 = repmat({'hESC'},34,1);
g = [g2; g3;g4;g5;g6;g7;g8];
boxplot(yhat,g);